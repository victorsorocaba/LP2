﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace AtividadeExtra
{
    public partial class frm1 : Form
    {
        public frm1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] tabela = new double[5, 7];
            string[] DiaSemana = { "Domingo", "Segunda", "Terca", "Quarta", "Quinta", "Sexta", "Sabado" };
            double[] resultado = new double[7];
            double total = 0;
            
            for (int i = 0; i < tabela.GetLength(0); i++)
            {
                for (int j = 0; j < tabela.GetLength(1); j++)
                {
                    string valorCompra = Interaction.InputBox($"Digite o valor da compra numero{j+1} na semana{DiaSemana[i]}");

                    if (!double.TryParse(valorCompra, out tabela[i, j]) || tabela[i, j] < 0) 
                    {
                        MessageBox.Show("Número Inválido!");
                        j--;
                    }
                    else
                    {
                        resultado[i] += tabela[i, j];

                        total += resultado[i];

                        
                    }
                  
                }
                lstbcValores.Items.Add($"{DiaSemana[i]} : {resultado[i]}");

            }
            lstbcValores.Items.Add($"Total Geral : {total}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbcValores.Items.Clear();
        }
    }
}
