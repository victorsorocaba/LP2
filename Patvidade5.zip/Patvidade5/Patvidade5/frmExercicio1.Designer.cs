﻿namespace Patvidade5
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEspaco = new System.Windows.Forms.Button();
            this.rcTxtBxFrase = new System.Windows.Forms.RichTextBox();
            this.btnR = new System.Windows.Forms.Button();
            this.btnPar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnEspaco
            // 
            this.btnEspaco.Location = new System.Drawing.Point(69, 309);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(144, 68);
            this.btnEspaco.TabIndex = 0;
            this.btnEspaco.Text = "Espaços em Brancos";
            this.btnEspaco.UseVisualStyleBackColor = true;
            // 
            // rcTxtBxFrase
            // 
            this.rcTxtBxFrase.Location = new System.Drawing.Point(69, 54);
            this.rcTxtBxFrase.Name = "rcTxtBxFrase";
            this.rcTxtBxFrase.Size = new System.Drawing.Size(655, 192);
            this.rcTxtBxFrase.TabIndex = 1;
            this.rcTxtBxFrase.Text = "";
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(319, 309);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(134, 68);
            this.btnR.TabIndex = 2;
            this.btnR.Text = "Vezes R";
            this.btnR.UseVisualStyleBackColor = true;
            // 
            // btnPar
            // 
            this.btnPar.Location = new System.Drawing.Point(585, 309);
            this.btnPar.Name = "btnPar";
            this.btnPar.Size = new System.Drawing.Size(139, 68);
            this.btnPar.TabIndex = 3;
            this.btnPar.Text = "Vezes Par";
            this.btnPar.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(238, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(283, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Digite uma frase";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnPar);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.rcTxtBxFrase);
            this.Controls.Add(this.btnEspaco);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.RichTextBox rcTxtBxFrase;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnPar;
        private System.Windows.Forms.Label label1;
    }
}