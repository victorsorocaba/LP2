﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso;
        double altura;
        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(mskbxPeso.Text, out peso) || (peso <= 0))
            {


                MessageBox.Show("Peso inválido!");

                mskbxPeso.Focus();

            }
        }

        private void mskbxAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(mskbxAltura.Text, out altura) || (altura <= 0))
            {


                MessageBox.Show("Altura inválido!");

                mskbxAltura.Focus();

            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double imc;
            imc = peso / Math.Pow(altura, 2);

            imc = Math.Round(imc, 1);


            txtIMC.Text = imc.ToString();

            if (imc < 18.5)
                MessageBox.Show("Magreza");

            else if (imc <= 24.9)
                MessageBox.Show("Normal");

            else if (imc <= 29.9)
                MessageBox.Show("Sobrepeso");
            else if (imc <= 39.0)
                MessageBox.Show("Obesidade");
            else
                MessageBox.Show("Obesidade Grave");






        }

        private void txtIMC_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtIMC.Clear();

            

            txtIMC.Focus();
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(mskbxAltura.Text, out altura) || (altura <= 0))
            {


                MessageBox.Show("Altura inválido!");

                mskbxAltura.Focus();

            }

        }
    }
}