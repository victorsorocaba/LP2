﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace AtividadeExtra2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] consumo = new double[5, 4];
            string[] setores = { "Produção", "Escritorio", "Refeitório", "Limpeza", "Logística" };
            string aux = "";
            double[] somaSemanal = new double[5];
            double totalGeral = 0;

            for (int i = 0; i < consumo.GetLength(0); i++ )
            {
                for (int j = 0; j < consumo.GetLength(1); j++ )
                
                {
                    aux = Interaction.InputBox("Digite o consumo do setor " + setores[i] + " na semana " + (j + 1) + ": ", "Consumo de Água(em litros)", "0");

                    if(!double.TryParse(aux, out consumo[i, j]) || consumo[i, j] < 0)
                    {
                        if(aux == "")
                        {
                            MessageBox.Show("Entrada cancelada. O programa será encerrado.");
                            return; // Encerra o programa se o usuário cancelar a entrada
                        }
                        MessageBox.Show("Valor inválido. Por favor, digite um número positivo.");
                        j--; // Volta para a mesma semana para tentar novamente
                    }
                    somaSemanal[i] += consumo[i, j];
                }
                lstbxConsumo.Items.Add($"{setores[i]} :  {somaSemanal[i]}L -> {somaSemanal[i]*0.01:C}");
                totalGeral += somaSemanal[i];
            }
            lstbxConsumo.Items.Add("---------------------------------");
            lstbxConsumo.Items.Add($"Total Geral: {totalGeral}L -> {totalGeral * 0.01:C}");
        }
    }
}
