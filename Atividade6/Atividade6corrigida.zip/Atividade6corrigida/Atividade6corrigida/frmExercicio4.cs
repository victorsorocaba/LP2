﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6corrigida
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] comprimento = new int[10];
            string nome = "";

            lstbxNomes.Items.Clear();

            for (int i = 0; i < nomes.Length; i++)
            {
                nome = Interaction.InputBox($"Digite o nome da {i + 1} pessoa", "Entrada de dados");

                if (string.IsNullOrWhiteSpace(nome))
                {
                    MessageBox.Show("Nome inválido, tente novamente.");
                    i--; // Decrementa para repetir a entrada
                }
                else
                {
                    nomes[i] = nome.Trim();
                    comprimento[i] = nomes[i].Replace(" ", "").Length;
                }


            }
            for (int i = 0; i < nomes.Length; i++)
            {
                lstbxNomes.Items.Add($"{nomes[i]} - {comprimento[i]} caracteres");
            }

        }
    }
}




