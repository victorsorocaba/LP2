﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6corrigida
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] matriz = new string[9, 10];
            string[] gabarito = new string[10] { "A", "B", "C", "D", "E", "A", "B", "C", "D", "E" };
            lstbxGabarito.Items.Clear();

            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    string resposta = Interaction.InputBox($"Digite a resposta do aluno {i + 1} para a questão {j + 1}", "Entrada de dados").ToUpper();

                    if (resposta != "A" && resposta != "B" && resposta != "C" && resposta != "D" && resposta != "E")
                    {
                        MessageBox.Show("Resposta inválida, tente novamente. As respostas válidas são: A, B, C, D ou E.");
                        j--; // Decrementa para repetir a entrada
                    }
                    else
                    {
                        matriz[i, j] = resposta;
                    }
                }
            }
            for (int i = 0; i < matriz.GetLength(0); i++)
            {

                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    if (matriz[i, j] == gabarito[j])
                    {
                        lstbxGabarito.Items.Add($"O Aluno {i + 1} acertou a questão {j + 1} era {gabarito[j]} escolheu {matriz[i, j]}");

                    }
                    else
                    {
                        lstbxGabarito.Items.Add($"O Aluno {i + 1} errou a questão {j + 1}  era {gabarito[j]} escolheu {matriz[i, j]}");
                    }

                }

            }
        }
    }
}
