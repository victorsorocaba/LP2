﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6corrigida
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1} numero", "Entrada de dados");

                if (!int.TryParse(aux, out vetor[i]))
                {
                    if(aux == "")
                    {
                        MessageBox.Show("Entrada cancelada. O programa será encerrado.");
                        return; // Encerra o método se o usuário cancelar a entrada
                    }
                    MessageBox.Show("Valor inválido, tente novamente.");
                    i--; // Decrementa para repetir a entrada

                }

            }
            Array.Reverse(vetor);
            aux = "";
            foreach (int num in vetor)
            {
                aux += num + "\n";
            }
            MessageBox.Show(aux, "Vetor invertido");
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList { "Ana", "Andre", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };

            alunos.Remove("Otávio");

            foreach (string aluno in alunos)
            {
                MessageBox.Show(aluno, "Lista de Alunos");
            }
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] alunoNota = new double[20, 3];
            string nota = "";
            double media = 0;
            string resultado = "";

            for (int i = 0; i < 20; i++)
            {

                for (int j = 0; j < 3; j++)
                {

                    nota = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de dados");

                    if (!double.TryParse(nota, out alunoNota[i, j]) || alunoNota[i, j] < 0 || alunoNota[i, j] > 9)
                    {
                        if(nota == "")
                        {
                            MessageBox.Show("Entrada cancelada. O programa será encerrado.");
                            return; // Encerra o método se o usuário cancelar a entrada
                        }
                        MessageBox.Show("Valor inválido, tente novamente. O valor não pode ser maior que 9 ou menor que 0");
                        j--; // Decrementa para repetir a entrada
                    }


                }
            }
            for (int i = 0; i < 20; i++)
            {

                {
                    media = (alunoNota[i, 0] + alunoNota[i, 1] + alunoNota[i, 2]) / 3;

                    resultado += $"Aluno {i + 1} = Média {media:F2}\n";

                }
                
            }
            MessageBox.Show(resultado, "Média dos alunos");
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms
                 .OfType<frmExercicio4>()
                 .Count() > 0)
            {
                MessageBox.Show("O formulário já está aberto");

                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 frm = new frmExercicio4();

                frm.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms
                .OfType<frmExercicio5>()
                .Count() > 0)
            {
                MessageBox.Show("O formulário já está aberto");

                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 frm = new frmExercicio5();

                frm.Show();
            }
        }
    }
}
