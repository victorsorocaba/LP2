﻿namespace Atividade6
{
    partial class frmGabarito
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnVerificar = new Button();
            lstGabarito = new ListBox();
            SuspendLayout();
            // 
            // btnVerificar
            // 
            btnVerificar.Location = new Point(29, 44);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(235, 110);
            btnVerificar.TabIndex = 0;
            btnVerificar.Text = "Verificar";
            btnVerificar.UseVisualStyleBackColor = true;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // lstGabarito
            // 
            lstGabarito.FormattingEnabled = true;
            lstGabarito.Location = new Point(425, 44);
            lstGabarito.Name = "lstGabarito";
            lstGabarito.Size = new Size(318, 379);
            lstGabarito.TabIndex = 1;
            // 
            // frmGabarito
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lstGabarito);
            Controls.Add(btnVerificar);
            Name = "frmGabarito";
            Text = "frmGabarito";
            ResumeLayout(false);
        }

        #endregion

        private Button btnVerificar;
        private ListBox lstGabarito;
    }
}