using Microsoft.VisualBasic;
using System.Collections;
using System.Security.Permissions;

namespace Atividade6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExer1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1} numero", "Entrada de dados");

                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido, tente novamente.");
                    i--; // Decrementa para repetir a entrada
                }

            }
            Array.Reverse(vetor);
            aux = "";
            foreach (int num in vetor)
            {
                aux += num + "\n";
            }
            MessageBox.Show(aux, "Vetor invertido");
        }

        private void btnExer2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList { "Ana", "Andre", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };

            alunos.Remove("Otávio");

            foreach (string aluno in alunos)
            {
                MessageBox.Show(aluno, "Lista de Alunos");
            }
        }

        private void btnExer3_Click(object sender, EventArgs e)
        {
            double[,] alunoNota = new double[20, 3];
            string nota = "";
            double media = 0;

            for (int i = 0; i < 20; i++)
            {

                for (int j = 0; j < 3; j++)
                {

                    nota = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de dados");

                    if (!double.TryParse(nota, out alunoNota[i, j]) || alunoNota[i, j] < 0 || alunoNota[i, j] > 9)
                    {
                        MessageBox.Show("Valor inválido, tente novamente. O valor não pode ser maior que 9 ou menor que 0");
                        j--; // Decrementa para repetir a entrada
                    }


                }
            }
            for (int i = 0; i < 20; i++)
            {

                {
                    media = (alunoNota[i, 0] + alunoNota[i, 1] + alunoNota[i, 2]) / 3;

                }
                MessageBox.Show($"A média do aluno {i + 1} é = {media:F2}");
            }
        }

        private void btnExer4_Click(object sender, EventArgs e)
        {
            frmComprimento frm = new frmComprimento();

            frm.Show();
        }

        private void btnExer5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms
                .OfType<frmGabarito>()
                .Count() > 0)
            {
                MessageBox.Show("O formulário já está aberto");

                Application.OpenForms["frmGabarito"].BringToFront();
            }
            else
            {
                frmGabarito frm = new frmGabarito();

                frm.Show();
            }
        }
    }

}