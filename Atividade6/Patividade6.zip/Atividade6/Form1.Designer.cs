﻿namespace Atividade6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExer1 = new Button();
            btnExer2 = new Button();
            btnExer3 = new Button();
            btnExer4 = new Button();
            btnExer5 = new Button();
            SuspendLayout();
            // 
            // btnExer1
            // 
            btnExer1.Location = new Point(78, 31);
            btnExer1.Name = "btnExer1";
            btnExer1.Size = new Size(186, 113);
            btnExer1.TabIndex = 0;
            btnExer1.Text = "Exercício 1";
            btnExer1.UseVisualStyleBackColor = true;
            btnExer1.Click += btnExer1_Click;
            // 
            // btnExer2
            // 
            btnExer2.Location = new Point(451, 31);
            btnExer2.Name = "btnExer2";
            btnExer2.Size = new Size(179, 113);
            btnExer2.TabIndex = 1;
            btnExer2.Text = "Exercício 2";
            btnExer2.UseVisualStyleBackColor = true;
            btnExer2.Click += btnExer2_Click;
            // 
            // btnExer3
            // 
            btnExer3.Location = new Point(78, 184);
            btnExer3.Name = "btnExer3";
            btnExer3.Size = new Size(186, 111);
            btnExer3.TabIndex = 2;
            btnExer3.Text = "Exercício 3";
            btnExer3.UseVisualStyleBackColor = true;
            btnExer3.Click += btnExer3_Click;
            // 
            // btnExer4
            // 
            btnExer4.Location = new Point(451, 184);
            btnExer4.Name = "btnExer4";
            btnExer4.Size = new Size(179, 111);
            btnExer4.TabIndex = 3;
            btnExer4.Text = "Exercício 4";
            btnExer4.UseVisualStyleBackColor = true;
            btnExer4.Click += btnExer4_Click;
            // 
            // btnExer5
            // 
            btnExer5.Location = new Point(269, 312);
            btnExer5.Name = "btnExer5";
            btnExer5.Size = new Size(180, 115);
            btnExer5.TabIndex = 4;
            btnExer5.Text = "Exercício 5";
            btnExer5.UseVisualStyleBackColor = true;
            btnExer5.Click += btnExer5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnExer5);
            Controls.Add(btnExer4);
            Controls.Add(btnExer3);
            Controls.Add(btnExer2);
            Controls.Add(btnExer1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnExer1;
        private Button btnExer2;
        private Button btnExer3;
        private Button btnExer4;
        private Button btnExer5;
    }
}
