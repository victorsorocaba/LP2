﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int numero1, numero2;

            if (!int.TryParse(txtNumero1.Text, out numero1) || numero1 < 0)
            {
                MessageBox.Show("N1 inválido!");
                txtNumero1.Focus();
            }
            else if (!int.TryParse(txtNumero2.Text, out numero2) || numero2 < 0)
            {
                MessageBox.Show("N2 inválido!");
                txtNumero2.Focus();
            }
        }
    }
}
