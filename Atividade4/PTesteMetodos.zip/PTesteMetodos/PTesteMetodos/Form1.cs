﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Opção Copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Opção Colar!!");
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio2>().Count() > 0)
            {
                Application.OpenForms["frmExercicio2"].BringToFront();
            }
            else
            {

                //Como instanciar um objeto: Classe(Nome da classe que vc criou), Nome do Objeto  = new Classe 
                FrmExercicio2 frmExercicio2 = new FrmExercicio2();
                frmExercicio2.MdiParent = this;
                frmExercicio2.Show();
            }
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio3>().Count() > 0)
            {
                Application.OpenForms["frmExercicio3"].BringToFront();
            }
            else
            {

                //Como instanciar um objeto: Classe(Nome da classe que vc criou), Nome do Objeto  = new Classe 
                FrmExercicio3 frmExercicio3 = new FrmExercicio3();
                frmExercicio3.MdiParent = this;
                frmExercicio3.Show();
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {

                //Como instanciar um objeto: Classe(Nome da classe que vc criou), Nome do Objeto  = new Classe 
                FrmExercicio4 frmExercicio4 = new FrmExercicio4();
                frmExercicio4.MdiParent = this;
                frmExercicio4.Show();
            }
        }
    }
}
