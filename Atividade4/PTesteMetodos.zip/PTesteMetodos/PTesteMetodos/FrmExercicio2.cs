﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void FrmExercicio2_Load(object sender, EventArgs e)
        {

        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            string P1 = txtPalavra1.Text;
            string P2 = txtPalavra2.Text;

            if (string.Compare(P1, P2, true) == 0)
            {
                MessageBox.Show("São iguais");
            }
            else
            {
                MessageBox.Show("São diferentes");
            }


        }

        private void btnInsert1_Click(object sender, EventArgs e)
        {
            int meio = txtPalavra2.Text.Length / 2;

            txtPalavra2.Text = txtPalavra2.Text.Substring(0, meio)
                             + txtPalavra1.Text
                             + txtPalavra2.Text.Substring(meio, txtPalavra2.Text.Length - meio);
        }

        private void btnInsert2_Click(object sender, EventArgs e)
        {
            string p1 = txtPalavra1.Text;

            int meio = p1.Length / 2;

            string resultado = p1.Substring(0, meio)
                             + "**"
                             + p1.Substring(meio);

            txtPalavra1.Text = resultado;
        }
    }
}
