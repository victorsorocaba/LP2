﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2;
        string resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {

            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(txtNumero2.Text, out numero2))
            {


                MessageBox.Show("Apenas números");

                txtNumero2.Focus();
            }

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = (numero1 - numero2).ToString();
            txtResultado.Text = resultado;
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = (numero1 * numero2).ToString();
            txtResultado.Text = resultado;
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0) {
                MessageBox.Show("Não é possivel dividir por zero");
                return;
            }
            resultado = (numero1 / numero2).ToString();
            txtResultado.Text = resultado;
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = (numero1 + numero2).ToString();
            txtResultado.Text = resultado;
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();

            numero1 = 0;
            numero2 = 0;
            resultado = "";

            txtNumero1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {
            txtResultado.Text = resultado;
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {

            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(txtNumero1.Text, out numero1))
            {


                MessageBox.Show("Apenas números");

                txtNumero1.Focus();


            }

        }
    }
}
