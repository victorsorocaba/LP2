﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        Double raio;
        Double altura;
        double volume;



        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtVolume.Text = volume.ToString("N2");
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            //Verifica se o controle que recebeu o clique
            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Raio inválido!");
                txtRaio.Focus();
            }

            else
            {
                if (raio <= 0)
                {
                    MessageBox.Show("Raio deve ser maior que zero!");
                    txtRaio.Focus();
                }
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            //Verifica se o controle que recebeu o clique
            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida!");
                txtAltura.Focus();  
            }

            else
            {
                if (altura <= 0)
                {
                    MessageBox.Show("Altura deve ser maior que zero!");
                    txtAltura.Focus();
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //limpar os dados
            txtAltura.Clear();
            txtRaio.Text = "";
            txtVolume.Text = String.Empty;

            raio = 0;
            altura = 0;
            volume = 0;

            //txtRaio.Focus();
        }
    }
}
