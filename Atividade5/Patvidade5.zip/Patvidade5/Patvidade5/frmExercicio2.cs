﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patvidade5
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtNumero_Validating(object sender, CancelEventArgs e)
        {
            if (int.TryParse(txtNumero.Text, out int numero))
            {
                if (numero <= 0)
                {
                    MessageBox.Show("Por favor, insira um número inteiro positivo.");
                    e.Cancel = true;
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira um número inteiro válido.");
                e.Cancel = true;


            }
        }

        private void btnNumeroH_Click(object sender, EventArgs e)
        {
            int numeroN = int.Parse(txtNumero.Text);
            double numeroH = 0;

            for (int i = 0; i < numeroN; i++)
            {
                numeroH += 1.0 / (i + 1);
                
            }
            MessageBox.Show($"O número H para N = {numeroN} é: {numeroH.ToString("F2")}");
        }
    }

}

