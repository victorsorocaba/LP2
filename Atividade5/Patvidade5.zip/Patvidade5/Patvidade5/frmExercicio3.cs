﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace Patvidade5
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtPalindromo_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPalindromo.Text))
            {
                MessageBox.Show("Por favor, insira uma palavra ou frase valida.");
                e.Cancel = true;
            }
        }

        private void btnPalindrimo_Click(object sender, EventArgs e)
        {
            string palindromo = txtPalindromo.Text.ToLower().Replace(" ", "");
            string inversa = new string(palindromo.Reverse().ToArray());

            if (palindromo == inversa)
            {
                MessageBox.Show($"A palavra ou frase é um palíndromo.");
            }
            else
            {
                MessageBox.Show($"A palavra ou frase não é um palíndromo.");


            }
        }
    }
}
