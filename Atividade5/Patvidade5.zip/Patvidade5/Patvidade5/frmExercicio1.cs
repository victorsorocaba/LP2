﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patvidade5
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void richTbxFrase_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            string frase = richTbxFrase.Text;
            int contarEspacos = 0;

            foreach (char caractere in frase)
            {
                if (caractere == ' ')
                {
                    contarEspacos++;
                }
            }
            MessageBox.Show($"A frase tem {contarEspacos} espaços.");

        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            string frase = richTbxFrase.Text.ToLower();
            int contarLetraR = 0;

            for (int i = 0; i < frase.Length; i++)
            {
                if (frase[i] == 'r')
                {
                    contarLetraR++;
                }

            }
            MessageBox.Show($"A frase tem {contarLetraR} letras R.");

        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            string frase = richTbxFrase.Text.ToLower();
            int contarPar = 0;
            int i = 0;

            while (i < frase.Length - 1)
            {
                if (frase[i] == frase[i + 1])
                {
                    contarPar++;
                    
                }
                i++;
            }
            MessageBox.Show($"A frase tem {contarPar} pares de letras iguais.");
        }
    }
}
