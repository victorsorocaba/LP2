﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patvidade5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void form1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio1>().Count() > 0)
            {
                Application.OpenForms["frmExercicio1"].BringToFront();
            }
            else
            {

                //Como instanciar um objeto: Classe(Nome da classe que vc criou), Nome do Objeto  = new Classe 
                frmExercicio1 frmExercicio1 = new frmExercicio1();
                frmExercicio1.MdiParent = this;
                frmExercicio1.Show();
            }
        }

        private void form2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0)
            {
                Application.OpenForms["frmExercicio2"].BringToFront();
            }
            else
            {

                //Como instanciar um objeto: Classe(Nome da classe que vc criou), Nome do Objeto  = new Classe 
                frmExercicio2 frmExercicio2 = new frmExercicio2();
                frmExercicio2.MdiParent = this;
                frmExercicio2.Show();
            }
        }

        private void form3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)
            {
                Application.OpenForms["frmExercicio3"].BringToFront();
            }
            else
            {

                //Como instanciar um objeto: Classe(Nome da classe que vc criou), Nome do Objeto  = new Classe 
                frmExercicio3 frmExercicio3 = new frmExercicio3();
                frmExercicio3.MdiParent = this;
                frmExercicio3.Show();
            }
        }

        private void form4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {

                //Como instanciar um objeto: Classe(Nome da classe que vc criou), Nome do Objeto  = new Classe 
                frmExercicio4 frmExercicio4 = new frmExercicio4();
                frmExercicio4.MdiParent = this;
                frmExercicio4.Show();
            }
        }
    }
}
