﻿namespace Patvidade5
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPalindrimo = new System.Windows.Forms.Button();
            this.txtPalindromo = new System.Windows.Forms.TextBox();
            this.lblPalindromo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnPalindrimo
            // 
            this.btnPalindrimo.Location = new System.Drawing.Point(56, 191);
            this.btnPalindrimo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnPalindrimo.Name = "btnPalindrimo";
            this.btnPalindrimo.Size = new System.Drawing.Size(209, 50);
            this.btnPalindrimo.TabIndex = 0;
            this.btnPalindrimo.Text = "É palíndromo?";
            this.btnPalindrimo.UseVisualStyleBackColor = true;
            this.btnPalindrimo.Click += new System.EventHandler(this.btnPalindrimo_Click);
            // 
            // txtPalindromo
            // 
            this.txtPalindromo.Location = new System.Drawing.Point(154, 80);
            this.txtPalindromo.MaxLength = 50;
            this.txtPalindromo.Name = "txtPalindromo";
            this.txtPalindromo.Size = new System.Drawing.Size(323, 20);
            this.txtPalindromo.TabIndex = 1;
            this.txtPalindromo.Validating += new System.ComponentModel.CancelEventHandler(this.txtPalindromo_Validating);
            // 
            // lblPalindromo
            // 
            this.lblPalindromo.AutoSize = true;
            this.lblPalindromo.Location = new System.Drawing.Point(53, 80);
            this.lblPalindromo.Name = "lblPalindromo";
            this.lblPalindromo.Size = new System.Drawing.Size(81, 13);
            this.lblPalindromo.TabIndex = 2;
            this.lblPalindromo.Text = "Digite a palavra";
            this.lblPalindromo.Click += new System.EventHandler(this.label1_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.lblPalindromo);
            this.Controls.Add(this.txtPalindromo);
            this.Controls.Add(this.btnPalindrimo);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPalindrimo;
        private System.Windows.Forms.TextBox txtPalindromo;
        private System.Windows.Forms.Label lblPalindromo;
    }
}