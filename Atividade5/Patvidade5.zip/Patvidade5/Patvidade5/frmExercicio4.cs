﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patvidade5
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double salario = double.Parse(txtSalario.Text);
            double producao = double.Parse(txtProducao.Text);
            double gratificacao = double.Parse(txtGratificacao.Text);


            int B = (producao >= 100) ? 1 : 0;
            int C = (producao >= 120) ? 1 : 0;
            int D = (producao >= 150) ? 1 : 0;

            double salariobruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

            if (salariobruto > 7000)
            {
                if (producao >= 150 && gratificacao > 0)
                {
                    MessageBox.Show($"O salário bruto do {txtNome.Text} é: R${salariobruto.ToString("F2")}, o funcionário tem direito a gratificação e a produção é maior ou igual a 150.");
                }
                else
                {
                    salariobruto = 7000;
                    MessageBox.Show($"O salário bruto do {txtNome.Text} é: R${salariobruto.ToString("F2")}, a produção é menor que 150.");
                }

            }
            else
            {
                MessageBox.Show($"O salário bruto do {txtNome.Text} é: R${salariobruto.ToString("F2")}");
            }
        }

        private void txtProducao_Validating(object sender, CancelEventArgs e)
        {
            if(!int.TryParse(txtProducao.Text, out int producao) || producao < 0)
            {
                MessageBox.Show("Por favor, insira um número inteiro positivo para a produção.");
                e.Cancel = true;
            }
        }

        private void txtSalario_Validating(object sender, CancelEventArgs e)
        {
            if(!double.TryParse(txtSalario.Text, out double salario) || salario < 0)
            {
                MessageBox.Show("Por favor, insira um número válido para o salário.");
                e.Cancel = true;
            }
        }

        private void txtGratificacao_Validating(object sender, CancelEventArgs e)
        {
            if(!double.TryParse(txtGratificacao.Text, out double gratificacao) || gratificacao < 0)
            {
                MessageBox.Show("Por favor, insira um número válido para a gratificação.");
                e.Cancel = true;
            }
        }
    }
}
