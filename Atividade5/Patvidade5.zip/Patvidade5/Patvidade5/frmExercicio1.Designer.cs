﻿namespace Patvidade5
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTbxFrase = new System.Windows.Forms.RichTextBox();
            this.btnEspaco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnPar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTbxFrase
            // 
            this.richTbxFrase.Location = new System.Drawing.Point(187, 110);
            this.richTbxFrase.Name = "richTbxFrase";
            this.richTbxFrase.Size = new System.Drawing.Size(392, 135);
            this.richTbxFrase.TabIndex = 0;
            this.richTbxFrase.Text = "";
            this.richTbxFrase.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.richTbxFrase_KeyPress);
            // 
            // btnEspaco
            // 
            this.btnEspaco.Location = new System.Drawing.Point(21, 309);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(177, 59);
            this.btnEspaco.TabIndex = 1;
            this.btnEspaco.Text = "Espaços em branco";
            this.btnEspaco.UseVisualStyleBackColor = true;
            this.btnEspaco.Click += new System.EventHandler(this.btnEspaco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(309, 309);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(161, 59);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Letra R";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnPar
            // 
            this.btnPar.Location = new System.Drawing.Point(569, 309);
            this.btnPar.Name = "btnPar";
            this.btnPar.Size = new System.Drawing.Size(172, 59);
            this.btnPar.TabIndex = 3;
            this.btnPar.Text = "Par de Letras";
            this.btnPar.UseVisualStyleBackColor = true;
            this.btnPar.Click += new System.EventHandler(this.btnPar_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnPar);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspaco);
            this.Controls.Add(this.richTbxFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTbxFrase;
        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnPar;
    }
}