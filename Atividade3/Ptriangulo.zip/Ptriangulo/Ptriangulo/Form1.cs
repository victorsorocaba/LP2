﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        Double valorA, valorB, valorC;

        private void txtValorB_Validated(object sender, EventArgs e)
        {

            try
            {
                errorProvider2.SetError(txtValorB, "");

                this.valorB = Convert.ToDouble(txtValorB.Text);
            }
            catch
            {
                errorProvider2.SetError(txtValorB, "Valor B inválido!");
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {

            try
            {
                errorProvider3.SetError(txtValorC, "");

                this.valorC = Convert.ToDouble(txtValorC.Text);
            }
            catch
            {
                errorProvider3.SetError(txtValorC, "Valor C inválido!");
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if ((valorA < (valorB + valorC)) &&
                (valorA > (Math.Abs(valorB - valorC))) &&
                (valorB < (valorA + valorC)) &&
                (valorB > (Math.Abs(valorA - valorC))) &&
                (valorC < (valorA + valorB)) &&
                (valorC > (Math.Abs(valorA - valorB))))
            {
                if (valorA == valorB && valorA == valorC)

                    MessageBox.Show("EQUILÁTERO");

                else if (valorA == valorB || valorA == valorC || valorB == valorC)

                    MessageBox.Show("ISÓSCELES");

                else

                    MessageBox.Show("ESCALENO");

            }
            else
            {
                MessageBox.Show("Não é um Triângulo");
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            valorA = 0;
            txtValorB.Clear();
            valorB = 0;
            txtValorC.Clear();
            valorC = 0;



        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtValorA, "");

                this.valorA = Convert.ToDouble(txtValorA.Text);
            }
            catch
            {
                errorProvider1.SetError(txtValorA, "Valor A inválido!");
            }
        }
    }
}
